from django.http import HttpResponse

def saveface(request):
    if request.method == "POST":
        img = request.FILES.get("img", None)
        f = open(u'static/facedata/base/' + img.name, "wb")
        for chunck in img.chunks():
            f.write(chunck)
        f.close()
        return HttpResponse("ok")
